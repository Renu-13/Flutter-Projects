import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          //title of my appbar is based on this
          title: Text('SHOPPING', style: TextStyle(
            fontSize: 24.0,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          ),
          centerTitle: true,
          backgroundColor: Colors.pinkAccent,
          //i gave shape to my appbar
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(20),
            ),
          ),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.shopping_cart),
              onPressed: () {
                // Handle shopping cart button press
              },
            ),
          ],
          leading: IconButton(
            icon: Icon(Icons.menu), // Icon with three lines
            onPressed: () {
              // Handle menu button press (open drawer or navigate to menu)
            },
          ),
        ),
      ),
    );
  }
}



